import {Component, OnInit} from '@angular/core';
import {CarService} from "../../service/car.service";
import {Router} from "@angular/router";
import {Car} from "../../model/car";

@Component({
    selector: 'app-cars',
    templateUrl: './cars.component.html',
    styleUrls: ['./cars.component.css'],
})
export class CarsComponent implements OnInit {

    cars = [];

    constructor(private carService: CarService,
                private router: Router) {
    }

    ngOnInit(): void {
        this.cars = [];

        // if (localStorage.getItem('secret') === null ||
        //     localStorage.getItem('secret') === undefined) {
        //     this.router.navigateByUrl('/login');
        // } else {
        //     this.movieService.getMovies().subscribe((data) => {
        //         this.movies = data;
        //     });
        // }
    }

    addCar() {
        // this.movieService.getMovieData().subscribe(movie => {
        //     this.movieService.addMovie(movie).subscribe((result) => {
        //         this.movies.push(result);
        //     });
        // });
    }

    applyDiscount(carId: number) {
        // this.movieService.applyDiscount(movieId).subscribe((result) => {
        //     this.movies.filter(m => m.id === movieId)[0].price = result;
        // });
    }

    update(car: Car) {
        // this.movieService.updateMovie(movie).subscribe((result) => {
        //     this.movies.filter(m => m.id === movie.id)[0] = result;
        // });
    }

    delete(carId: number) {
        // this.movieService.deleteMovie(movieId).subscribe(() => {
        //     this.movies = this.movies.filter(m => m.id !== movieId);
        // });
    }
}
