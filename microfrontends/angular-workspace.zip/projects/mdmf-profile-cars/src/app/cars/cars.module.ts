import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';

import {CarsRoutingModule} from './cars-routing.module';
import {CarsComponent} from './cars.component';
import {HttpClientModule} from "@angular/common/http";
import {CarService} from "../../service/car.service";

@NgModule({
    declarations: [CarsComponent],
    imports: [CommonModule, CarsRoutingModule, HttpClientModule],
    providers: [CarService]
})
export class CarsModule {
}
