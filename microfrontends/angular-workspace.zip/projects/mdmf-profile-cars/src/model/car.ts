export class Car {
    id: string;
    name: string;
    description: string;
    price: number;

}
