import {Injectable} from "@angular/core";
import {HttpClient} from "@angular/common/http";
import {Observable} from "rxjs";
import {Car} from "../model/car";

@Injectable({
    providedIn: 'root'
})
export class CarService {

    URL = 'http://localhost:3000/api/car/';
    NODE_RED_URL = 'http://localhost:1880/car';

    constructor(
        private httpClient: HttpClient
    ) {
    }


    getCars(): Observable<any> {

        const authorization = localStorage.getItem('secret');
        const newUrl = this.URL;
        const headers = {'content-type': 'application/json', 'Authorization': `Bearer ${authorization}`};
        return this.httpClient.get(newUrl, {headers});
    }

    getCarData(): Observable<any> {

        const headers = {'content-type': 'application/json'};
        return this.httpClient.get(this.NODE_RED_URL, {headers});
    }


    applyDiscount(carId: number): Observable<any> {

        const authorization = localStorage.getItem('secret');
        const newUrl = this.URL + 'price-async/' + carId;
        const headers = {'content-type': 'application/json', 'Authorization': `Bearer ${authorization}`};
        return this.httpClient.get(newUrl, {headers});
    }

    deleteCar(id: number): Observable<any> {

        const authorization = localStorage.getItem('secret');
        const newUrl = this.URL + id;
        const headers = {'content-type': 'application/json', 'Authorization': `Bearer ${authorization}`};
        return this.httpClient.delete(newUrl, {headers});
    }

    updateCar(car: Car): Observable<any> {

        const authorization = localStorage.getItem('secret');
        const newUrl = this.URL + car.id;
        const headers = {'content-type': 'application/json', 'Authorization': `Bearer ${authorization}`};
        return this.httpClient.put(newUrl, car, {headers});
    }

    addCar(car: Car): Observable<any> {

        const authorization = localStorage.getItem('secret');
        const headers = {'content-type': 'application/json', 'Authorization': `Bearer ${authorization}`};
        return this.httpClient.post(this.URL, car, {headers});
    }
}