const webpack = require('webpack');
const ModuleFederationPlugin = require('webpack/lib/container/ModuleFederationPlugin');

module.exports = {
    output: {
        publicPath: 'http://localhost:4202/',
        uniqueName: 'mdmfprofilecars',
    },
    optimization: {
        runtimeChunk: false,
    },
    plugins: [
        new ModuleFederationPlugin({
            name: 'cars',
            library: {type: 'var', name: 'cars'},
            filename: 'remoteEntry.js',
            exposes: {
                CarsModule: './projects/mdmf-profile-cars/src/app/cars/cars.module.ts',
            },
            shared: {
                '@angular/core': {eager: true, singleton: true},
                '@angular/common': {eager: true, singleton: true},
                '@angular/router': {eager: true, singleton: true},
            },
        }),
    ],
};
