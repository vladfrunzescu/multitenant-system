import {Component, OnInit} from '@angular/core';
import {MovieService} from "../../service/movie.service";
import {Router} from "@angular/router";
import {Movie} from "../../model/movie";

@Component({
    selector: 'app-movies',
    templateUrl: './movies.component.html',
    styleUrls: ['./movies.component.css'],
})
export class MoviesComponent implements OnInit {

    movies = [];

    constructor(private movieService: MovieService,
                private router: Router) {
    }

    ngOnInit(): void {
        // this.movies = [];

        if (localStorage.getItem('secret') === null ||
            localStorage.getItem('secret') === undefined) {
            this.router.navigateByUrl('/login');
        } else {
            this.movieService.getMovies().subscribe((data) => {
                this.movies = data;
            });
        }
    }

    addMovie() {
        this.movieService.getMovieData().subscribe(movie => {
            this.movieService.addMovie(movie).subscribe((result) => {
                this.movies.push(result);
            });
        });
    }

    applyDiscount(movieId: number) {
        this.movieService.applyDiscount(movieId).subscribe((result) => {
            this.movies.filter(m => m.id === movieId)[0].price = result;
        });
    }

    update(movie: Movie) {
        this.movieService.updateMovie(movie).subscribe((result) => {
            this.movies.filter(m => m.id === movie.id)[0] = result;
        });
    }

    delete(movieId: number) {
        this.movieService.deleteMovie(movieId).subscribe(() => {
            this.movies = this.movies.filter(m => m.id !== movieId);
        });
    }
}
