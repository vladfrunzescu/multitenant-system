export class Movie {
    id: string;
    name: string;
    description: string;
    price: number;

}
