import {Injectable} from "@angular/core";
import {HttpClient} from "@angular/common/http";
import {Observable} from "rxjs";
import {Movie} from "../model/movie";

@Injectable({
    providedIn: 'root'
})
export class MovieService {

    URL = 'http://localhost:3000/api/movie/';
    NODE_RED_URL = 'http://localhost:1880/movie';

    constructor(
        private httpClient: HttpClient
    ) {
    }


    getMovies(): Observable<any> {

        const authorization = localStorage.getItem('secret');
        const newUrl = this.URL;
        const headers = {'content-type': 'application/json', 'Authorization': `Bearer ${authorization}`};
        return this.httpClient.get(newUrl, {headers});
    }

    getMovieData(): Observable<any> {

        const headers = {'content-type': 'application/json'};
        return this.httpClient.get(this.NODE_RED_URL, {headers});
    }


    applyDiscount(movieId: number): Observable<any> {

        const authorization = localStorage.getItem('secret');
        const newUrl = this.URL + 'price-async/' + movieId;
        const headers = {'content-type': 'application/json', 'Authorization': `Bearer ${authorization}`};
        return this.httpClient.get(newUrl, {headers});
    }

    deleteMovie(id: number): Observable<any> {

        const authorization = localStorage.getItem('secret');
        const newUrl = this.URL + id;
        const headers = {'content-type': 'application/json', 'Authorization': `Bearer ${authorization}`};
        return this.httpClient.delete(newUrl, {headers});
    }

    updateMovie(movie: Movie): Observable<any> {

        const authorization = localStorage.getItem('secret');
        const newUrl = this.URL + movie.id;
        const headers = {'content-type': 'application/json', 'Authorization': `Bearer ${authorization}`};
        return this.httpClient.put(newUrl, movie, {headers});
    }

    addMovie(movie: Movie): Observable<any> {

        const authorization = localStorage.getItem('secret');
        const headers = {'content-type': 'application/json', 'Authorization': `Bearer ${authorization}`};
        return this.httpClient.post(this.URL, movie, {headers});
    }
}