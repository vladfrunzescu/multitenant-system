import {NgModule} from '@angular/core';
import {Routes, RouterModule} from '@angular/router';
import {LoginComponent} from './login/login.component';
import {loadRemoteModule} from './utils/utils';
import {MoviesModule} from "../../../mdmf-profile/src/app/movies/movies.module";
import {CarsModule} from "../../../mdmf-profile-cars/src/app/cars/cars.module";

const routes: Routes = [
    {path: '', redirectTo: 'login', pathMatch: 'full'},
    {path: 'login', component: LoginComponent},
    {
        path: 'movies',
        loadChildren: () =>
            loadRemoteModule({
                remoteName: 'movies',
                remoteEntry: 'http://localhost:4201/remoteEntry.js',
                exposedModule: 'MoviesModule',
            }).then(m => m.MoviesModule),
    },
    {
        path: 'cars',
        loadChildren: () =>
            loadRemoteModule({
                remoteName: 'cars',
                remoteEntry: 'http://localhost:4202/remoteEntry.js',
                exposedModule: 'CarsModule',
            }).then(m => m.CarsModule),
    },
];

@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule],
})
export class AppRoutingModule {
}
