import {Component} from '@angular/core';
import {AppService} from "../service/app.service";
import {Router} from "@angular/router";

@Component({
    selector: 'app-login',
    templateUrl: './login.component.html',
    styleUrls: ['./login.component.scss'],
})
export class LoginComponent {
    email: string = "";
    password: string = "";

    constructor(private appService: AppService,
                private router: Router) {
    }

    login() {
        localStorage.setItem('secret', 'access_token');
        // this.router.navigateByUrl('/cars');
        // this.router.navigateByUrl('/movies');

        this.appService.login({username: this.email, password: this.password})
            .subscribe((result) => {
                localStorage.setItem('secret', result.access_token);
                this.router.navigateByUrl('/movies');
            });
    }
}
