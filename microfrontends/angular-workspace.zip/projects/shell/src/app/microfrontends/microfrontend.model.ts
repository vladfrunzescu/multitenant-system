import { LoadRemoteModuleOptions } from '../utils/utils';

export type MovieMicroFE = LoadRemoteModuleOptions & {
  displayName: string;
  routePath: string;
  ngModuleName: string;
};
