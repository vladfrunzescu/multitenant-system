import {Injectable} from '@angular/core';
import {Router} from '@angular/router';
import {buildRoutes} from '../utils/route-utils';
import {MovieMicroFE} from './microfrontend.model';

@Injectable({providedIn: 'root'})
export class MicrofrontendService {
    frontends: MovieMicroFE[];

    constructor(private router: Router) {
    }


    initialise(): Promise<void> {
        return new Promise<void>((resolve, reject) => {
            this.frontends = this.loadConfig();
            this.router.resetConfig(buildRoutes(this.frontends));
            resolve();
        });
    }


    loadConfig(): MovieMicroFE[] {
        return [
            {
                remoteEntry: 'http://localhost:4201/remoteEntry.js',
                remoteName: 'movies',
                exposedModule: 'MoviesModule',

                displayName: 'Movies',
                routePath: 'movies',
                ngModuleName: 'MoviesModule',
            },
            {
                remoteEntry: 'http://localhost:4202/remoteEntry.js',
                remoteName: 'cars',
                exposedModule: 'CarsModule',

                displayName: 'Cars',
                routePath: 'cars',
                ngModuleName: 'CarsModule',
            },
        ];
    }
}
