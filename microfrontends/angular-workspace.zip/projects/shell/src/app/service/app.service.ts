import { Injectable} from "@angular/core";
import {HttpClient} from "@angular/common/http";
import {User} from "../model/user.model";
import {Observable} from "rxjs";


@Injectable({
    providedIn: 'root'
})
export class AppService {

    URL = 'http://localhost:3000/api/';

    constructor(
        private httpClient: HttpClient
    ) {
    }


    login(user: User): Observable<any> {

        const newUrl = this.URL + 'auth/login';

        const headers = {'content-type': 'application/json'};
        const body = JSON.stringify(user);

        return this.httpClient.post(newUrl, body, {headers});
    }
}
